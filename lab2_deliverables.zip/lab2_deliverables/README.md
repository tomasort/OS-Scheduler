# NYU OS Lab 2

Net-ID: tor213


Name: Tomas Ortega Rojas

# Important Information

For some reason in the previous lab I thought that we could not use c++11 in linserv1 but my current makefile seems to work without using module load. But If needed, use ```module load gcc-9.2``` to create the executable, use ```make```